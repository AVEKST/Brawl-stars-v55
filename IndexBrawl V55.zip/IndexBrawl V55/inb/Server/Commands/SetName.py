def get_username():
    username = input("Enter your nickname: ")
    return username

if __name__ == "__main__":
    username = get_username()
    print("Welcome,", username)