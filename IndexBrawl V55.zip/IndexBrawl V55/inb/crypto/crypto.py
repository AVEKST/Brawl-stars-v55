from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
from Crypto.Protocol.KDF import PBKDF2

def encrypt_text(key, plaintext):
    # Generate a salt
    salt = get_random_bytes(AES.block_size)
    
    # Derive key from password using PBKDF2
    derived_key = PBKDF2(key, salt, dkLen=32)
    
    # Initialize AES cipher
    cipher = AES.new(derived_key, AES.MODE_CFB)
    
    # Encrypt the text
    ciphertext = cipher.encrypt(plaintext.encode('utf-8'))
    
    # Return the ciphertext and salt
    return ciphertext, salt

def decrypt_text(key, ciphertext, salt):
    # Derive key from password using PBKDF2
    derived_key = PBKDF2(key, salt, dkLen=32)
    
    # Initialize AES cipher
    cipher = AES.new(derived_key, AES.MODE_CFB)
    
    # Decrypt the text
    plaintext = cipher.decrypt(ciphertext).decode('utf-8')
    
    # Return the decrypted text
    return plaintext

# Example usage
key = b'my_secret_key'  # Key
plaintext = "Hello, World!"  # Text to encrypt

# Encrypt the text
ciphertext, salt = encrypt_text(key, plaintext)
print("Encrypted Text:", ciphertext)

# Decrypt the text
decrypted_text = decrypt_text(key, ciphertext, salt)
print("Decrypted Text:", decrypted_text)