import socket
import threading
import sqlite3
import dns.resolver
from tinydb import TinyDB, Query
from colorama import init, Fore
from schedule import Scheduler

# Initialize colorama
init(autoreset=True)

# Initialize the game database
db = TinyDB('DataBase.json')

# Create tables if they don't exist
conn = sqlite3.connect('game_data.db')
cursor = conn.cursor()
cursor.execute('''CREATE TABLE IF NOT EXISTS players
                  (id INTEGER PRIMARY KEY, username TEXT, score INTEGER)''')
conn.commit()
conn.close()

# Function to handle client connections
def handle_client(client_socket, address):
    print(Fore.GREEN + f"[NEW CONNECTION] {address} connected.")

    # Send a welcome message to the client
    client_socket.send("Core.py running!".encode())

    # Main loop to receive and handle client messages
    while True:
        # Receive data from the client
        data = client_socket.recv(1024).decode()

        # If the client disconnects, break out of the loop
        if not data:
            print(Fore.RED + f"[DISCONNECTED] {address} disconnected.")
            break

        # Process the received data
        # Add your game logic here
        
    # Close the client socket
    client_socket.close()

# Function to start the server
def start_server():
    # Define server settings
    SERVER_HOST = '0.0.0.0'
    SERVER_PORT = 9339

    # Create a TCP socket
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    # Bind the socket to the address and port
    server_socket.bind((SERVER_HOST, SERVER_PORT))

    # Start listening for incoming connections
    server_socket.listen(5)
    print(Fore.BLUE + f"[LISTENING] Server is listening on {SERVER_HOST}:{SERVER_PORT}")

    # Main server loop to accept incoming connections
    while True:
        # Accept a new connection
        client_socket, address = server_socket.accept()

        # Start a new thread to handle the client
        client_thread = threading.Thread(target=handle_client, args=(client_socket, address))
        client_thread.start()

# Function to schedule server tasks
def schedule_tasks():
    # Add your scheduled tasks here
    pass

if __name__ == "__main__":
    # Start the server
    start_server()

    # Schedule server tasks
    scheduler = Scheduler()
    scheduler.every().hour.do(schedule_tasks)

    # Main loop to execute scheduled tasks
    while True:
        scheduler.run_pending()