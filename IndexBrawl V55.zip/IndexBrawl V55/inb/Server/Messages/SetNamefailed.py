def login():
    # Set the correct username
    correct_username = "player"

    # Get the username input from the user
    username = input("Enter your username: ")

    # Check if the entered username is correct
    if username == correct_username:
        print("Logging in OK!")
    else:
        print("Username incorrect!")

if __name__ == "__main__":
    login()