import subprocess

# Install Crypto module
subprocess.run(["pip", "install", "crypto"])

# Install RSA module
subprocess.run(["pip", "install", "rsa"])

# Install pycryptodome module
subprocess.run(["pip", "install", "pycryptodome"])